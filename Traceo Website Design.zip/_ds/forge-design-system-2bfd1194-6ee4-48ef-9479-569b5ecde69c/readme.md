# Forge Design System

**Forge** is a mobile workspace for developers and technical professionals — a calm place to track projects, deploys, pull requests, reviews and team activity from a phone. The design system delivers the VS Code virtues of **clarity, structure and professional restraint**, rebuilt natively for one-thumb mobile use rather than as a shrunken desktop UI.

It is **dark-first** and tuned for long, late-night sessions: no pure black, no pure white, a single confident azure accent, generous spacing, and quiet motion.

> **Design persona, in 10 words:** vibrant, colorful, energetic, premium, legible, technical, confident, modern, focused, warm.

## Sources
This system was authored from scratch — **no external codebase, Figma file, or brand kit was provided**. All identity, naming, palette, type and component decisions are original to this project. If a brand reference exists, attach it and the system can be re-tuned to match.

**Substitutions to confirm (see CAVEATS):** fonts load from Google Fonts CDN; icons use the Lucide CDN. Both should be self-hosted for production.

---

## CONTENT FUNDAMENTALS — how Forge writes

- **Voice:** plain, precise, quietly confident. We sound like a senior engineer who respects your time, not a marketer.
- **Person:** address the user as **you**; the product refers to itself rarely and never in first person. Greetings are warm but short — *"Good evening, Lina."*
- **Casing:** **Sentence case everywhere** — buttons, titles, nav, menu items (*"Open PR"*, *"Create an account"*, *"Email digests"*). The only uppercase is the tiny tracked label style (section headers like `ACCOUNT`, `PREFERENCES`).
- **Length:** ruthless brevity. Buttons are 1–2 words (*Deploy*, *Open PR*, *Sign in*). Empty-state bodies are one calm sentence. Metadata is compressed (*"main · deployed 4m ago"*).
- **Numbers & status:** lead with the number, label underneath (*4 / Deploys*). Status is a single lowercase word in a tinted pill (*live*, *staging*, *building*).
- **Technical vocabulary is welcome:** branches, PRs, checks, deploys, coverage — the audience is fluent, so we don't over-explain. Monospace is used for anything machine-literal (branch names, commit SHAs, versions, timestamps).
- **Tone in failure:** factual, never alarmist. *"Build failed — 2 checks did not pass."* No exclamation marks, no blame.
- **Emoji:** never. Status and meaning come from icons + color, not emoji.
- **Examples:** *"Tuesday, June 10 · 4 things need you"*, *"Welcome back — sign in to your Northwind workspace."*, *"You're all caught up."*

---

## VISUAL FOUNDATIONS

**Palette.** Forge v2 is **vibrant and colorful, dark-only**. A warm **Amber** leads (`#FF8A22` fill / `#FF9B3D` bright-on-dark) and carries every primary action, active state, link and focus ring. Unlike a restrained one-accent system, a **full spectrum of vivid hues** (coral, pink, violet, blue, cyan, green, yellow) is used decoratively and for data — language tiles, category dots, charts. Lively **gradients** (`--grad-hero` amber→pink→violet, plus warm/cool/mint) power heroes, the app mark and highlights. Semantic colors: success `#3FD179`, warning `#FFC53D`, error `#FF5C72`. The base is a neutral-cool dark (`#131217` canvas → `#22212B` cards) chosen specifically so the colors pop. No pure black, dark-only — no light theme.

**Type.** `IBM Plex Sans Arabic` — a single bilingual (Arabic + Latin) face for all UI text, paired with `JetBrains Mono` for technical metadata. Tight tracking on large headings (`-0.02em`), comfortable `1.55` line-height on body. Weights: 700 for display/headings, 600 for titles/buttons, 500 for labels, 400 for body.

**Spacing & layout.** 4px base grid. Phone screens use a **20px outer margin**, 28px between major sections, 12–16px inside card stacks. Content is left-aligned (RTL-mirrored for Arabic); only empty states and onboarding center. Generous white space is the primary tool for making a dense, data-rich screen feel calm.

**Corners.** Soft and structured: 8px buttons/inputs, 12px cards/rows, 16–22px sheets, pill for chips/avatars/FAB. Nothing sharp, nothing bubbly.

**Borders.** 1px hairlines (`--border`) separate and contain; 1.5px (`--border-strong`) outlines inputs and emphasizes. Borders do more visual work here than shadows.

**Shadows.** Low and soft. `shadow-sm/md/lg` are quiet; the only assertive shadow is the azure-tinted lift under the FAB and primary lifts (`--shadow-accent`).

**Imagery.** This is a tool, not a gallery — there is little photography. Identity comes from typography, the azure accent, language-colored dots, and iconography. No gradients-as-decoration; the one gradient is a near-black radial behind the device frame.

**Motion.** Calm, quick, deliberate. Durations 120 / 200 / 320ms; standard easing `cubic-bezier(.2,.6,.2,1)`, emphasized `cubic-bezier(.2,.85,.25,1)` for sheets/entrances. Nothing bounces hard or overshoots. Onboarding slides fade-up 8px; toasts rise 12px; the page-dot stretches between steps.

**Press / interaction states.** Tappables shrink on press (`scale 0.97`, icon buttons `0.92`) — a physical, reassuring cue rather than a color flash. Selected chips/rows fill with the 14% azure tint. Inputs raise to an azure 1.5px border + a 3px soft focus ring. Disabled drops to 45% opacity.

**Transparency & blur.** Used sparingly: tinted-color fills (`accent-subtle`, semantic `-subtle`) for selected/badge backgrounds, and a `62%` scrim behind sheets/modals. No frosted-glass everywhere.

**Cards.** Tinted surface, 1px border, 12px radius, **no shadow at rest**; raised variant gets `shadow-md`; selected swaps the border to azure. This is the signature container.

---

## ICONOGRAPHY

- **System:** [Lucide](https://lucide.dev) — outline, **1.8px stroke**, 22px default, drawn in `currentColor` so icons inherit text/accent color. One family only; no mixed fills, no duotone, no emoji, no unicode glyphs as icons.
- **Delivery:** loaded from the Lucide CDN. In React it's wrapped by the `Icon` component (`<Icon name="rocket" />`); in plain HTML cards it's `<i data-lucide="…">` + `lucide.createIcons(...)`.
- **Usage:** active/brand icons take the azure accent; everything else is `--text-secondary` or `--text-muted`. Status icons borrow semantic colors (`check-circle-2` success, `x-circle`/`alert-triangle` error/warning). Domain icons lean on Git vocabulary: `git-branch`, `git-pull-request`, `git-merge`, `git-commit-horizontal`, `rocket`, `terminal`, `activity`.
- **Brand mark:** a `hexagon` glyph on an azure tile (see Brand cards) — a forge/anvil-adjacent, technical motif.
- **Substitution flag:** Lucide is an original choice (no source brand was supplied). For production, pin a Lucide version or self-host the SVGs.

---

## Index / manifest

**Foundations**
- `styles.css` — the one file consumers link (imports only).
- `tokens/` — `fonts.css`, `colors.css` (light + dark), `typography.css`, `spacing.css`, `radius.css`, `motion.css`, `base.css`.

**Design System tab cards** (`guidelines/`)
- Type: `type-scale`, `type-bilingual`
- Colors: `color-brand`, `color-surfaces-dark`, `color-surfaces-light`, `color-semantic`, `color-text`
- Spacing: `spacing-scale`, `radius`, `elevation`, `motion`
- Brand: `brand-logo`, `iconography`

**Components** (`components/`, namespace `window.<DS namespace>` — run the design-system check to get the exact name)
- `core/` — Button, IconButton, Card, Badge, Chip, Avatar
- `forms/` — Input, SearchBar, Switch
- `navigation/` — AppBar, SegmentedTabs, ListItem, BottomNav
- `feedback/` — Toast, Skeleton, EmptyState

**UI kit** (`ui_kits/`)
- `forge-app/` — interactive Forge mobile app (Splash, Onboarding, Login, Home, Search, Details, Activity, Profile/Settings).

**Other**
- `SKILL.md` — packaged skill instructions for reuse outside this project.
