/* @ds-bundle: {"format":3,"namespace":"ForgeDesignSystem_2bfd11","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/Skeleton.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"SearchBar","sourcePath":"components/forms/SearchBar.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"AppBar","sourcePath":"components/navigation/AppBar.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"ListItem","sourcePath":"components/navigation/ListItem.jsx"},{"name":"SegmentedTabs","sourcePath":"components/navigation/SegmentedTabs.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"fb4023a20ba7","components/core/Badge.jsx":"0c9027e77241","components/core/Button.jsx":"8f62c2632cc2","components/core/Card.jsx":"43ad3a86110a","components/core/Chip.jsx":"03ddc82d793e","components/core/IconButton.jsx":"4a9fa12818a1","components/feedback/EmptyState.jsx":"f4728f4d0570","components/feedback/Skeleton.jsx":"a594d0c47054","components/feedback/Toast.jsx":"cad88a2c45c4","components/forms/Input.jsx":"87d66b65a192","components/forms/SearchBar.jsx":"0cc6505fdd86","components/forms/Switch.jsx":"e2d8bb6273a8","components/navigation/AppBar.jsx":"7809e28dafc9","components/navigation/BottomNav.jsx":"4016f7412e14","components/navigation/ListItem.jsx":"5353167e8cfc","components/navigation/SegmentedTabs.jsx":"01fbaa4e91f9","ui_kits/forge-app/app.jsx":"95ffc0224e05","ui_kits/forge-app/data.jsx":"0f730b022e4d","ui_kits/forge-app/forge-ui-core.jsx":"74b3c441ffc0","ui_kits/forge-app/forge-ui-nav.jsx":"292c7db6bf97","ui_kits/forge-app/screen-auth.jsx":"a466f235340e","ui_kits/forge-app/screen-details.jsx":"735e5285d729","ui_kits/forge-app/screen-home.jsx":"f6339ffc8cbf","ui_kits/forge-app/screen-profile.jsx":"0e7895b74b59","ui_kits/forge-app/screen-search.jsx":"b738701d4480"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ForgeDesignSystem_2bfd11 = window.ForgeDesignSystem_2bfd11 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
/**
 * Avatar — image or initials fallback. status adds a presence dot.
 * size: sm 28 | md 40 | lg 56
 */
function Avatar({
  src,
  name = '',
  size = 'md',
  status = null,
  style = {}
}) {
  const dim = size === 'sm' ? 28 : size === 'lg' ? 56 : 40;
  const initials = name.split(' ').map(w => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  const statusColors = {
    online: 'var(--success)',
    busy: 'var(--error)',
    away: 'var(--warning)',
    offline: 'var(--text-muted)'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      width: dim,
      height: dim,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: dim,
      height: dim,
      borderRadius: 'var(--r-pill)',
      overflow: 'hidden',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-3)',
      color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: dim * 0.38,
      border: '1px solid var(--border)'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1,
      width: dim * 0.3,
      height: dim * 0.3,
      borderRadius: '50%',
      background: statusColors[status],
      border: '2px solid var(--surface)'
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
/**
 * Small status pill. tone: neutral | accent | success | warning | error
 * variant: subtle (tinted bg) | solid | outline
 */
function Badge({
  children,
  tone = 'neutral',
  variant = 'subtle',
  dot = false,
  style = {}
}) {
  const tones = {
    neutral: {
      c: 'var(--text-secondary)',
      bg: 'var(--surface-3)',
      solid: 'var(--text-muted)'
    },
    accent: {
      c: 'var(--accent)',
      bg: 'var(--accent-subtle)',
      solid: 'var(--accent-fill)'
    },
    success: {
      c: 'var(--success)',
      bg: 'var(--success-subtle)',
      solid: 'var(--success)'
    },
    warning: {
      c: 'var(--warning)',
      bg: 'var(--warning-subtle)',
      solid: 'var(--warning)'
    },
    error: {
      c: 'var(--error)',
      bg: 'var(--error-subtle)',
      solid: 'var(--error)'
    }
  };
  const t = tones[tone];
  const styles = {
    subtle: {
      color: t.c,
      background: t.bg,
      border: '1px solid transparent'
    },
    solid: {
      color: '#fff',
      background: t.solid,
      border: '1px solid transparent'
    },
    outline: {
      color: t.c,
      background: 'transparent',
      border: `1px solid ${t.c}`
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 22,
      padding: '0 9px',
      borderRadius: 'var(--r-pill)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-tiny)',
      fontWeight: 'var(--fw-semibold)',
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
      lineHeight: 1,
      ...styles[variant],
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: variant === 'solid' ? '#fff' : t.c
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Forge primary control. Calm, structured, AA-contrast fills.
 * variant: primary | secondary | ghost | danger
 * size: md (52) | sm (40)
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  leadingIcon = null,
  trailingIcon = null,
  onClick,
  type = 'button',
  style = {},
  ...rest
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    height: size === 'sm' ? 'var(--button-h-sm)' : 'var(--button-h)',
    padding: size === 'sm' ? '0 16px' : '0 22px',
    width: fullWidth ? '100%' : 'auto',
    fontFamily: 'var(--font-sans)',
    fontSize: size === 'sm' ? 'var(--fs-body-sm)' : 'var(--fs-button)',
    fontWeight: 'var(--fw-semibold)',
    letterSpacing: '0.01em',
    borderRadius: 'var(--r-sm)',
    border: '1px solid transparent',
    cursor: disabled || loading ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'transform var(--dur-fast) var(--ease-standard), background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)',
    WebkitTapHighlightColor: 'transparent',
    userSelect: 'none',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--accent-fill)',
      color: 'var(--accent-fg)'
    },
    secondary: {
      background: 'var(--surface-3)',
      color: 'var(--text)',
      borderColor: 'var(--border-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--accent)'
    },
    danger: {
      background: 'var(--error)',
      color: '#fff'
    }
  };
  const press = e => {
    if (!disabled && !loading) e.currentTarget.style.transform = 'scale(var(--press-scale))';
  };
  const release = e => {
    e.currentTarget.style.transform = 'scale(1)';
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled || loading,
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: release,
    onPointerLeave: release,
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      border: '2px solid currentColor',
      borderTopColor: 'transparent',
      borderRadius: '50%',
      display: 'inline-block',
      animation: 'forge-spin 0.7s linear infinite'
    }
  }) : leadingIcon, !loading && children, !loading && trailingIcon, /*#__PURE__*/React.createElement("style", null, '@keyframes forge-spin{to{transform:rotate(360deg)}}'));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Surface container. Forge cards lean on a tinted surface + hairline border,
 * with low shadow only when raised. interactive=true adds press feedback.
 */
function Card({
  children,
  padding = 'var(--card-pad)',
  raised = false,
  interactive = false,
  selected = false,
  onClick,
  style = {},
  ...rest
}) {
  const press = e => {
    if (interactive) e.currentTarget.style.transform = 'scale(0.99)';
  };
  const release = e => {
    if (interactive) e.currentTarget.style.transform = 'scale(1)';
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: release,
    onPointerLeave: release,
    style: {
      background: 'var(--surface-2)',
      border: `1px solid ${selected ? 'var(--accent)' : 'var(--border)'}`,
      borderRadius: 'var(--r-md)',
      padding,
      boxShadow: raised ? 'var(--shadow-md)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      transition: 'transform var(--dur-fast) var(--ease-standard), border-color var(--dur-base) var(--ease-standard), background var(--dur-base) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
/**
 * Selectable / filter chip. Toggles between rest and selected.
 */
function Chip({
  children,
  selected = false,
  leadingIcon = null,
  onClick,
  disabled = false,
  style = {}
}) {
  const press = e => {
    if (!disabled) e.currentTarget.style.transform = 'scale(0.96)';
  };
  const release = e => {
    e.currentTarget.style.transform = 'scale(1)';
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    disabled: disabled,
    onPointerDown: press,
    onPointerUp: release,
    onPointerLeave: release,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 34,
      padding: '0 14px',
      borderRadius: 'var(--r-pill)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-medium)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      color: selected ? 'var(--accent)' : 'var(--text-secondary)',
      background: selected ? 'var(--accent-subtle)' : 'var(--surface-2)',
      border: `1px solid ${selected ? 'var(--accent)' : 'var(--border)'}`,
      transition: 'transform var(--dur-fast) var(--ease-standard), background var(--dur-base) var(--ease-standard), color var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, leadingIcon, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Square tap target for a single icon. Use in app bars, list rows, toolbars.
 * variant: ghost | surface | accent
 * size: md (44) | sm (36)
 */
function IconButton({
  children,
  label,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const dim = size === 'sm' ? 36 : 44;
  const variants = {
    ghost: {
      background: 'transparent',
      color: 'var(--text-secondary)'
    },
    surface: {
      background: 'var(--surface-3)',
      color: 'var(--text)',
      border: '1px solid var(--border)'
    },
    accent: {
      background: 'var(--accent-subtle)',
      color: 'var(--accent)'
    }
  };
  const press = e => {
    if (!disabled) e.currentTarget.style.transform = 'scale(0.92)';
  };
  const release = e => {
    e.currentTarget.style.transform = 'scale(1)';
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: release,
    onPointerLeave: release,
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--r-sm)',
      border: '1px solid transparent',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'transform var(--dur-fast) var(--ease-standard), background var(--dur-fast) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
/**
 * Empty / zero state. Centered icon in a soft tile, title, supporting line,
 * optional action. Used for empty lists, no results, first-run.
 */
function EmptyState({
  icon = null,
  title,
  description = null,
  action = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 14,
      padding: '40px 24px',
      maxWidth: 360,
      margin: '0 auto',
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 'var(--r-lg)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-3)',
      border: '1px solid var(--border)',
      color: 'var(--text-muted)'
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-h3)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text)'
    }
  }, title), description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--lh-normal)'
    }
  }, description)), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Skeleton.jsx
try { (() => {
/**
 * Skeleton placeholder. Shimmer is calm (1.4s) and respects reduced motion.
 * variant: line | block | circle
 */
function Skeleton({
  variant = 'line',
  width = '100%',
  height,
  radius,
  style = {}
}) {
  const dims = {
    line: {
      width,
      height: height || 12,
      borderRadius: radius || 'var(--r-xs)'
    },
    block: {
      width,
      height: height || 80,
      borderRadius: radius || 'var(--r-md)'
    },
    circle: {
      width: width || 40,
      height: height || 40,
      borderRadius: '50%'
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'linear-gradient(90deg, var(--surface-2) 25%, var(--surface-3) 37%, var(--surface-2) 63%)',
      backgroundSize: '400% 100%',
      animation: 'forge-shimmer 1.4s ease-in-out infinite',
      ...dims[variant],
      ...style
    }
  }, /*#__PURE__*/React.createElement("style", null, `
        @keyframes forge-shimmer { 0% { background-position: 100% 0 } 100% { background-position: 0 0 } }
        @media (prefers-reduced-motion: reduce) { div { animation: none !important } }
      `));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/**
 * Inline toast / snackbar surface. tone tints the leading accent rail + icon.
 * Render inside a fixed container; this component is presentational.
 */
function Toast({
  title,
  message = null,
  tone = 'neutral',
  icon = null,
  action = null,
  onClose,
  style = {}
}) {
  const tones = {
    neutral: 'var(--text-secondary)',
    accent: 'var(--accent)',
    success: 'var(--success)',
    warning: 'var(--warning)',
    error: 'var(--error)'
  };
  const c = tones[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      padding: '14px 14px 14px 16px',
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderLeft: `3px solid ${c}`,
      borderRadius: 'var(--r-md)',
      boxShadow: 'var(--shadow-lg)',
      minWidth: 280,
      maxWidth: 440,
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: c,
      display: 'inline-flex',
      marginTop: 1
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text)'
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, message)), action, onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      display: 'inline-flex',
      padding: 2,
      fontSize: 14
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text field with label + optional helper/error. Outlined, 52px tall.
 * Focus raises the border to accent + soft ring.
 */
function Input({
  label,
  value,
  onChange,
  placeholder = '',
  type = 'text',
  helper = '',
  error = '',
  leadingIcon = null,
  trailingIcon = null,
  disabled = false,
  style = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const borderColor = error ? 'var(--error)' : focused ? 'var(--accent)' : 'var(--border-strong)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 'var(--field-h)',
      padding: '0 14px',
      background: 'var(--surface-3)',
      border: `1.5px solid ${borderColor}`,
      borderRadius: 'var(--r-sm)',
      boxShadow: focused && !error ? '0 0 0 3px var(--accent-ring)' : 'none',
      opacity: disabled ? 0.5 : 1,
      transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)'
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    type: type,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text)'
    }
  }, rest)), trailingIcon), (error || helper) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-caption)',
      color: error ? 'var(--error)' : 'var(--text-muted)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Search field — pill, filled surface, leading search icon supplied by caller.
 */
function SearchBar({
  value,
  onChange,
  placeholder = 'Search',
  leadingIcon = null,
  onClear,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 46,
      padding: '0 14px',
      background: 'var(--surface-3)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-pill)',
      ...style
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text)'
    }
  }, rest)), value && onClear && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClear,
    "aria-label": "Clear",
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      display: 'inline-flex',
      padding: 2
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { SearchBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchBar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
/**
 * iOS-style toggle. 52x32 track, smooth thumb travel.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 52,
      height: 32,
      flexShrink: 0,
      borderRadius: 'var(--r-pill)',
      border: 'none',
      position: 'relative',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      background: checked ? 'var(--accent-fill)' : 'var(--surface-3)',
      boxShadow: checked ? 'none' : 'inset 0 0 0 1px var(--border-strong)',
      transition: 'background var(--dur-base) var(--ease-standard)',
      padding: 0,
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 23 : 3,
      width: 26,
      height: 26,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.4)',
      transition: 'left var(--dur-base) var(--ease-emphasized)'
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/AppBar.jsx
try { (() => {
/**
 * Top app bar. Left slot (back/menu), centered or leading title, right actions.
 * 56px, sits on --surface with a hairline bottom border when scrolled.
 */
function AppBar({
  title,
  leading = null,
  actions = null,
  subtitle = null,
  scrolled = false,
  centerTitle = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 'var(--appbar-h)',
      padding: '0 8px',
      background: 'var(--surface)',
      borderBottom: `1px solid ${scrolled ? 'var(--border)' : 'transparent'}`,
      transition: 'border-color var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, leading, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: centerTitle ? 'center' : 'flex-start',
      paddingLeft: leading ? 0 : 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-h3)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      maxWidth: '100%'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-caption)',
      color: 'var(--text-muted)'
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 2
    }
  }, actions));
}
Object.assign(__ds_scope, { AppBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/AppBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
/**
 * Bottom navigation bar. items: [{ key, label, icon, activeIcon?, badge? }]
 * Icons supplied by caller (e.g. Lucide nodes). Active item shows accent + label.
 */
function BottomNav({
  items = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'stretch',
      height: 'var(--tabbar-h)',
      background: 'var(--surface)',
      borderTop: '1px solid var(--border)',
      paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      ...style
    }
  }, items.map(it => {
    const active = it.key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      type: "button",
      onClick: () => onChange && onChange(it.key),
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 4,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: '6px 0',
        color: active ? 'var(--accent)' : 'var(--text-muted)',
        transition: 'color var(--dur-base) var(--ease-standard)',
        WebkitTapHighlightColor: 'transparent',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'inline-flex'
      }
    }, it.icon, it.badge != null && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -4,
        right: -7,
        minWidth: 16,
        height: 16,
        padding: '0 4px',
        borderRadius: 'var(--r-pill)',
        background: 'var(--error)',
        color: '#fff',
        fontSize: 10,
        fontWeight: 700,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: '2px solid var(--surface)'
      }
    }, it.badge)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 10,
        fontWeight: active ? 600 : 500,
        letterSpacing: '0.01em'
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ListItem.jsx
try { (() => {
/**
 * List row. Leading slot (icon/avatar), title + subtitle, trailing slot.
 * Tappable rows get press feedback + optional chevron.
 */
function ListItem({
  leading = null,
  title,
  subtitle = null,
  trailing = null,
  onClick,
  selected = false,
  style = {}
}) {
  const tappable = !!onClick;
  const press = e => {
    if (tappable) e.currentTarget.style.background = 'var(--surface-3)';
  };
  const release = e => {
    if (tappable) e.currentTarget.style.background = selected ? 'var(--accent-subtle)' : 'transparent';
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: release,
    onPointerLeave: release,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      minHeight: 'var(--tap-comfort)',
      padding: '10px 4px',
      background: selected ? 'var(--accent-subtle)' : 'transparent',
      cursor: tappable ? 'pointer' : 'default',
      transition: 'background var(--dur-fast) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, leading && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexShrink: 0
    }
  }, leading), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, subtitle)), trailing && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexShrink: 0,
      color: 'var(--text-muted)'
    }
  }, trailing));
}
Object.assign(__ds_scope, { ListItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ListItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SegmentedTabs.jsx
try { (() => {
/**
 * Segmented control / underlined tabs. tabs: [{ key, label }]
 * variant: segmented (filled pill) | underline
 */
function SegmentedTabs({
  tabs = [],
  value,
  onChange,
  variant = 'segmented',
  style = {}
}) {
  if (variant === 'underline') {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 4,
        borderBottom: '1px solid var(--border)',
        ...style
      }
    }, tabs.map(t => {
      const active = t.key === value;
      return /*#__PURE__*/React.createElement("button", {
        key: t.key,
        type: "button",
        onClick: () => onChange && onChange(t.key),
        style: {
          border: 'none',
          background: 'transparent',
          cursor: 'pointer',
          padding: '12px 14px',
          position: 'relative',
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body)',
          fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
          color: active ? 'var(--text)' : 'var(--text-muted)',
          transition: 'color var(--dur-base) var(--ease-standard)'
        }
      }, t.label, /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          left: 10,
          right: 10,
          bottom: -1,
          height: 2,
          borderRadius: 2,
          background: active ? 'var(--accent)' : 'transparent',
          transition: 'background var(--dur-base) var(--ease-standard)'
        }
      }));
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 3,
      padding: 3,
      background: 'var(--surface-3)',
      borderRadius: 'var(--r-sm)',
      border: '1px solid var(--border)',
      ...style
    }
  }, tabs.map(t => {
    const active = t.key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: t.key,
      type: "button",
      onClick: () => onChange && onChange(t.key),
      style: {
        flex: 1,
        border: 'none',
        cursor: 'pointer',
        padding: '8px 12px',
        borderRadius: 'calc(var(--r-sm) - 2px)',
        background: active ? 'var(--surface)' : 'transparent',
        boxShadow: active ? 'var(--shadow-sm)' : 'none',
        color: active ? 'var(--text)' : 'var(--text-muted)',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body-sm)',
        fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        transition: 'all var(--dur-base) var(--ease-standard)',
        WebkitTapHighlightColor: 'transparent'
      }
    }, t.label);
  }));
}
Object.assign(__ds_scope, { SegmentedTabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SegmentedTabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/app.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Forge UI kit — app shell, phone frame, navigation. window.ForgeApp */
(function () {
  const {
    Icon,
    BottomNav,
    FAB,
    Toast,
    Badge,
    AppBar,
    IconButton,
    EmptyState
  } = window.ForgeUI;
  const S = window.ForgeScreens;
  const D = window.ForgeData;
  function StatusBar({
    light
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: 44,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 24px 0 28px',
        flexShrink: 0,
        color: 'var(--text)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        fontWeight: 600
      }
    }, "9:41"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "signal",
      size: 16
    }), /*#__PURE__*/React.createElement(Icon, {
      name: "wifi",
      size: 16
    }), /*#__PURE__*/React.createElement(Icon, {
      name: "battery-full",
      size: 18
    })));
  }
  function Activity() {
    const [filter, setFilter] = React.useState('all');
    const list = filter === 'unread' ? D.notifications.filter(n => n.unread) : D.notifications;
    const tones = {
      accent: 'var(--accent)',
      error: 'var(--error)',
      success: 'var(--success)',
      neutral: 'var(--text-secondary)'
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: "Activity",
      actions: /*#__PURE__*/React.createElement(IconButton, {
        label: "Mark all read"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "check-check",
        size: 20
      }))
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '4px var(--screen-pad) 10px',
        display: 'flex',
        gap: 8
      }
    }, [{
      k: 'all',
      l: 'All'
    }, {
      k: 'unread',
      l: 'Unread'
    }].map(t => /*#__PURE__*/React.createElement("button", {
      key: t.k,
      type: "button",
      onClick: () => setFilter(t.k),
      style: {
        height: 32,
        padding: '0 14px',
        borderRadius: 'var(--r-pill)',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        fontWeight: 500,
        border: `1px solid ${filter === t.k ? 'var(--accent)' : 'var(--border)'}`,
        color: filter === t.k ? 'var(--accent)' : 'var(--text-secondary)',
        background: filter === t.k ? 'var(--accent-subtle)' : 'var(--surface-2)'
      }
    }, t.l))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '4px var(--screen-pad) 96px'
      }
    }, list.length === 0 && /*#__PURE__*/React.createElement(EmptyState, {
      icon: "bell-off",
      title: "No unread",
      description: "You're all caught up."
    }), list.map(n => /*#__PURE__*/React.createElement("div", {
      key: n.id,
      style: {
        display: 'flex',
        gap: 12,
        padding: '13px 4px',
        borderBottom: '1px solid var(--border)',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 38,
        height: 38,
        borderRadius: 'var(--r-sm)',
        flexShrink: 0,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--surface-3)',
        color: tones[n.tone]
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 18
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 14.5,
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, n.title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13.5,
        color: 'var(--text-secondary)',
        marginTop: 1
      }
    }, n.body), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--text-muted)',
        marginTop: 3
      }
    }, n.when, " ago")), n.unread && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: 'var(--accent)',
        flexShrink: 0,
        marginTop: 6
      }
    })))));
  }
  function App() {
    const [authed, setAuthed] = React.useState(false);
    const [tab, setTab] = React.useState('home');
    const [project, setProject] = React.useState(null);
    const [toast, setToast] = React.useState(null);
    const showToast = t => {
      setToast(t);
      setTimeout(() => setToast(null), 2600);
    };
    let screen;
    if (project) {
      screen = /*#__PURE__*/React.createElement(S.Details, {
        project: project,
        onBack: () => setProject(null)
      });
    } else if (tab === 'home') {
      screen = /*#__PURE__*/React.createElement(S.Home, {
        onOpenProject: setProject,
        onSearch: () => setTab('search'),
        onBell: () => setTab('activity'),
        unread: 2
      });
    } else if (tab === 'search') {
      screen = /*#__PURE__*/React.createElement(S.Search, {
        onOpenProject: setProject
      });
    } else if (tab === 'activity') {
      screen = /*#__PURE__*/React.createElement(Activity, null);
    } else {
      screen = /*#__PURE__*/React.createElement(S.Profile, null);
    }
    const navItems = [{
      key: 'home',
      label: 'Home',
      icon: 'layout-grid'
    }, {
      key: 'search',
      label: 'Search',
      icon: 'search'
    }, {
      key: 'activity',
      label: 'Activity',
      icon: 'bell',
      badge: 2
    }, {
      key: 'profile',
      label: 'Profile',
      icon: 'user-round'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        background: 'var(--bg)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        position: 'relative'
      }
    }, authed ? screen : /*#__PURE__*/React.createElement(S.Auth, {
      onAuthed: () => {
        setAuthed(true);
        setTimeout(() => showToast({
          tone: 'success',
          icon: 'check-circle-2',
          title: 'Signed in',
          message: 'Welcome back to Northwind.'
        }), 200);
      }
    })), authed && tab === 'home' && !project && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        right: 18,
        bottom: 'calc(var(--tabbar-h) + 18px)'
      }
    }, /*#__PURE__*/React.createElement(FAB, {
      icon: "plus",
      onClick: () => showToast({
        tone: 'accent',
        icon: 'folder-plus',
        title: 'New project',
        message: 'Create flow would open here.'
      })
    })), authed && !project && /*#__PURE__*/React.createElement(BottomNav, {
      value: tab,
      onChange: setTab,
      items: navItems
    }), toast && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: 16,
        right: 16,
        bottom: authed && !project ? 'calc(var(--tabbar-h) + 14px)' : 24,
        animation: 'ftoast var(--dur-slow) var(--ease-emphasized) both',
        zIndex: 20
      }
    }, /*#__PURE__*/React.createElement(Toast, _extends({}, toast, {
      onClose: () => setToast(null)
    }))), /*#__PURE__*/React.createElement("style", null, '@keyframes ftoast{from{transform:translateY(14px)}to{transform:translateY(0)}}'));
  }
  window.ForgeApp = App;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/data.jsx
try { (() => {
/* Forge UI kit — sample data. window.ForgeData */
window.ForgeData = {
  user: {
    name: 'Lina Khoury',
    handle: 'lina',
    role: 'Staff Engineer',
    workspace: 'Northwind'
  },
  summary: {
    deploys: 4,
    prs: 7,
    failing: 2,
    uptime: 99.97,
    coverage: 86
  },
  projects: [{
    id: 'pay',
    name: 'Payments API',
    branch: 'main',
    status: 'live',
    checks: 'passing',
    updated: '4m',
    lang: 'Go',
    stars: 128,
    desc: 'Card, wallet and payout services.',
    progress: 92,
    members: ['Lina K', 'Omar R', 'Sara M']
  }, {
    id: 'web',
    name: 'Web Banking',
    branch: 'release/2.4',
    status: 'staging',
    checks: 'passing',
    updated: '22m',
    lang: 'TypeScript',
    stars: 96,
    desc: 'Customer-facing banking dashboard.',
    progress: 74,
    members: ['Omar R', 'Yara T']
  }, {
    id: 'ml',
    name: 'ML Pipeline',
    branch: 'feature/embed',
    status: 'building',
    checks: 'failing',
    updated: '1h',
    lang: 'Python',
    stars: 54,
    desc: 'Fraud scoring and embeddings.',
    progress: 38,
    members: ['Sara M', 'Lina K']
  }, {
    id: 'auth',
    name: 'Identity',
    branch: 'main',
    status: 'live',
    checks: 'passing',
    updated: '3h',
    lang: 'Rust',
    stars: 210,
    desc: 'Authentication and session service.',
    progress: 100,
    members: ['Yara T']
  }, {
    id: 'mob',
    name: 'Mobile App',
    branch: 'develop',
    status: 'staging',
    checks: 'passing',
    updated: '5h',
    lang: 'Kotlin',
    stars: 77,
    desc: 'iOS & Android client.',
    progress: 61,
    members: ['Omar R', 'Sara M', 'Lina K', 'Yara T']
  }],
  activity: [{
    id: 1,
    who: 'Omar R',
    action: 'merged',
    target: 'PR #482 · Add idempotency keys',
    repo: 'Payments API',
    when: '6m',
    icon: 'git-merge',
    tone: 'accent'
  }, {
    id: 2,
    who: 'CI',
    action: 'failed on',
    target: '2 checks · embed-eval',
    repo: 'ML Pipeline',
    when: '18m',
    icon: 'x-circle',
    tone: 'error'
  }, {
    id: 3,
    who: 'Sara M',
    action: 'deployed',
    target: 'v2.4.1 to production',
    repo: 'Payments API',
    when: '32m',
    icon: 'rocket',
    tone: 'success'
  }, {
    id: 4,
    who: 'Yara T',
    action: 'opened',
    target: 'PR #128 · Rotate signing keys',
    repo: 'Identity',
    when: '1h',
    icon: 'git-pull-request',
    tone: 'accent'
  }, {
    id: 5,
    who: 'You',
    action: 'commented on',
    target: 'Issue #54 · Rate limiting',
    repo: 'Web Banking',
    when: '2h',
    icon: 'message-square',
    tone: 'neutral'
  }],
  notifications: [{
    id: 1,
    title: 'Build failed',
    body: 'ML Pipeline · embed-eval did not pass.',
    when: '18m',
    tone: 'error',
    icon: 'alert-triangle',
    unread: true
  }, {
    id: 2,
    title: 'Review requested',
    body: 'Omar asked you to review PR #482.',
    when: '40m',
    tone: 'accent',
    icon: 'eye',
    unread: true
  }, {
    id: 3,
    title: 'Deploy complete',
    body: 'Payments API v2.4.1 is live.',
    when: '1h',
    tone: 'success',
    icon: 'check-circle-2',
    unread: false
  }, {
    id: 4,
    title: 'New comment',
    body: 'Sara replied on Issue #54.',
    when: '3h',
    tone: 'neutral',
    icon: 'message-square',
    unread: false
  }],
  langColors: {
    Go: '#2BD4C4',
    TypeScript: '#4D9DFF',
    Python: '#FFC53D',
    Rust: '#FF5C72',
    Kotlin: '#9B6BFF'
  },
  statusTone: {
    live: 'success',
    staging: 'warning',
    building: 'accent'
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/forge-ui-core.jsx
try { (() => {
/* Forge UI kit — inline primitives mirroring the design-system components,
   styled entirely from styles.css tokens so the kit stays on-brand and
   renders standalone. Shared via window.ForgeUI. */

// ---- Icon (Lucide) ----
function Icon({
  name,
  size = 22,
  stroke = 1.8,
  color,
  style = {}
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (el && window.lucide) {
      el.innerHTML = `<i data-lucide="${name}"></i>`;
      window.lucide.createIcons({
        attrs: {
          width: size,
          height: size,
          'stroke-width': stroke
        }
      });
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      color,
      ...style
    }
  });
}

// ---- Button ----
function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth,
  disabled,
  loading,
  leadingIcon,
  trailingIcon,
  onClick,
  style = {}
}) {
  const variants = {
    primary: {
      background: 'var(--accent-fill)',
      color: 'var(--accent-fg)'
    },
    secondary: {
      background: 'var(--surface-3)',
      color: 'var(--text)',
      border: '1px solid var(--border-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--accent)'
    },
    danger: {
      background: 'var(--error)',
      color: '#fff'
    }
  };
  const press = e => {
    if (!disabled && !loading) e.currentTarget.style.transform = 'scale(0.97)';
  };
  const rel = e => e.currentTarget.style.transform = 'scale(1)';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled || loading,
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: rel,
    onPointerLeave: rel,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      height: size === 'sm' ? 40 : 'var(--button-h)',
      padding: size === 'sm' ? '0 16px' : '0 22px',
      width: fullWidth ? '100%' : 'auto',
      fontFamily: 'var(--font-sans)',
      fontSize: size === 'sm' ? 'var(--fs-body-sm)' : 'var(--fs-button)',
      fontWeight: 600,
      letterSpacing: '0.01em',
      borderRadius: 'var(--r-sm)',
      border: '1px solid transparent',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--dur-fast) var(--ease-standard), background var(--dur-fast) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      userSelect: 'none',
      whiteSpace: 'nowrap',
      ...variants[variant],
      ...style
    }
  }, loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      border: '2px solid currentColor',
      borderTopColor: 'transparent',
      borderRadius: '50%',
      animation: 'fspin .7s linear infinite'
    }
  }) : leadingIcon, !loading && children, !loading && trailingIcon, /*#__PURE__*/React.createElement("style", null, '@keyframes fspin{to{transform:rotate(360deg)}}'));
}

// ---- IconButton ----
function IconButton({
  children,
  label,
  variant = 'ghost',
  size = 'md',
  onClick,
  style = {}
}) {
  const dim = size === 'sm' ? 36 : 44;
  const variants = {
    ghost: {
      background: 'transparent',
      color: 'var(--text-secondary)'
    },
    surface: {
      background: 'var(--surface-3)',
      color: 'var(--text)',
      border: '1px solid var(--border)'
    },
    accent: {
      background: 'var(--accent-subtle)',
      color: 'var(--accent)'
    }
  };
  const press = e => e.currentTarget.style.transform = 'scale(0.92)';
  const rel = e => e.currentTarget.style.transform = 'scale(1)';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: rel,
    onPointerLeave: rel,
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--r-sm)',
      border: '1px solid transparent',
      cursor: 'pointer',
      transition: 'transform var(--dur-fast) var(--ease-standard), background var(--dur-fast) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...variants[variant],
      ...style
    }
  }, children);
}

// ---- Card ----
function Card({
  children,
  padding = 'var(--card-pad)',
  raised,
  interactive,
  selected,
  onClick,
  style = {}
}) {
  const press = e => {
    if (interactive) e.currentTarget.style.transform = 'scale(0.99)';
  };
  const rel = e => {
    if (interactive) e.currentTarget.style.transform = 'scale(1)';
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: rel,
    onPointerLeave: rel,
    style: {
      background: 'var(--surface-2)',
      border: `1px solid ${selected ? 'var(--accent)' : 'var(--border)'}`,
      borderRadius: 'var(--r-md)',
      padding,
      boxShadow: raised ? 'var(--shadow-md)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      transition: 'transform var(--dur-fast) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, children);
}

// ---- Badge ----
function Badge({
  children,
  tone = 'neutral',
  variant = 'subtle',
  dot,
  style = {}
}) {
  const tones = {
    neutral: {
      c: 'var(--text-secondary)',
      bg: 'var(--surface-3)',
      solid: 'var(--text-muted)'
    },
    accent: {
      c: 'var(--accent)',
      bg: 'var(--accent-subtle)',
      solid: 'var(--accent-fill)'
    },
    success: {
      c: 'var(--success)',
      bg: 'var(--success-subtle)',
      solid: 'var(--success)'
    },
    warning: {
      c: 'var(--warning)',
      bg: 'var(--warning-subtle)',
      solid: 'var(--warning)'
    },
    error: {
      c: 'var(--error)',
      bg: 'var(--error-subtle)',
      solid: 'var(--error)'
    }
  };
  const t = tones[tone];
  const sv = {
    subtle: {
      color: t.c,
      background: t.bg
    },
    solid: {
      color: '#fff',
      background: t.solid
    },
    outline: {
      color: t.c,
      background: 'transparent',
      border: `1px solid ${t.c}`
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 22,
      padding: '0 9px',
      borderRadius: 'var(--r-pill)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-tiny)',
      fontWeight: 600,
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
      lineHeight: 1,
      ...sv[variant],
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: variant === 'solid' ? '#fff' : t.c
    }
  }), children);
}

// ---- Chip ----
function Chip({
  children,
  selected,
  leadingIcon,
  onClick,
  style = {}
}) {
  const press = e => e.currentTarget.style.transform = 'scale(0.96)';
  const rel = e => e.currentTarget.style.transform = 'scale(1)';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: rel,
    onPointerLeave: rel,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 34,
      padding: '0 14px',
      borderRadius: 'var(--r-pill)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 500,
      cursor: 'pointer',
      color: selected ? 'var(--accent)' : 'var(--text-secondary)',
      background: selected ? 'var(--accent-subtle)' : 'var(--surface-2)',
      border: `1px solid ${selected ? 'var(--accent)' : 'var(--border)'}`,
      transition: 'all var(--dur-base) var(--ease-standard)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, leadingIcon, children);
}

// ---- Avatar ----
function Avatar({
  src,
  name = '',
  size = 'md',
  status,
  style = {}
}) {
  const dim = size === 'sm' ? 28 : size === 'lg' ? 56 : 40;
  const initials = name.split(' ').map(w => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  const sc = {
    online: 'var(--success)',
    busy: 'var(--error)',
    away: 'var(--warning)',
    offline: 'var(--text-muted)'
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      width: dim,
      height: dim,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: dim,
      height: dim,
      borderRadius: 'var(--r-pill)',
      overflow: 'hidden',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-3)',
      color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: dim * 0.38,
      border: '1px solid var(--border)'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1,
      width: dim * 0.3,
      height: dim * 0.3,
      borderRadius: '50%',
      background: sc[status],
      border: '2px solid var(--surface)'
    }
  }));
}

// ---- Input ----
function Input({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  helper,
  error,
  leadingIcon,
  trailingIcon,
  style = {}
}) {
  const [f, setF] = React.useState(false);
  const bc = error ? 'var(--error)' : f ? 'var(--accent)' : 'var(--border-strong)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 500,
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 'var(--field-h)',
      padding: '0 14px',
      background: 'var(--surface-3)',
      border: `1.5px solid ${bc}`,
      borderRadius: 'var(--r-sm)',
      boxShadow: f && !error ? '0 0 0 3px var(--accent-ring)' : 'none',
      transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)'
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    type: type,
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text)'
    }
  }), trailingIcon), (error || helper) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-caption)',
      color: error ? 'var(--error)' : 'var(--text-muted)'
    }
  }, error || helper));
}

// ---- SearchBar ----
function SearchBar({
  value,
  onChange,
  placeholder = 'Search',
  leadingIcon,
  onClear,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 46,
      padding: '0 14px',
      background: 'var(--surface-3)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-pill)',
      ...style
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text)'
    }
  }), value && onClear && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClear,
    "aria-label": "Clear",
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 13
    }
  }, "\u2715"));
}

// ---- Switch ----
function Switch({
  checked,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    onClick: () => onChange && onChange(!checked),
    style: {
      width: 52,
      height: 32,
      flexShrink: 0,
      borderRadius: 'var(--r-pill)',
      border: 'none',
      position: 'relative',
      cursor: 'pointer',
      background: checked ? 'var(--accent-fill)' : 'var(--surface-3)',
      boxShadow: checked ? 'none' : 'inset 0 0 0 1px var(--border-strong)',
      transition: 'background var(--dur-base) var(--ease-standard)',
      padding: 0,
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 23 : 3,
      width: 26,
      height: 26,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.4)',
      transition: 'left var(--dur-base) var(--ease-emphasized)'
    }
  }));
}
Object.assign(window, {
  ForgeUI: {
    Icon,
    Button,
    IconButton,
    Card,
    Badge,
    Chip,
    Avatar,
    Input,
    SearchBar,
    Switch
  }
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/forge-ui-core.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/forge-ui-nav.jsx
try { (() => {
/* Forge UI kit — navigation + feedback primitives. Extends window.ForgeUI. */
(function () {
  const {
    Icon,
    Badge
  } = window.ForgeUI;

  // ---- AppBar ----
  function AppBar({
    title,
    subtitle,
    leading,
    actions,
    scrolled,
    centerTitle,
    style = {}
  }) {
    return /*#__PURE__*/React.createElement("header", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        height: 'var(--appbar-h)',
        padding: '0 8px',
        background: 'var(--surface)',
        borderBottom: `1px solid ${scrolled ? 'var(--border)' : 'transparent'}`,
        transition: 'border-color var(--dur-base) var(--ease-standard)',
        ...style
      }
    }, leading, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: centerTitle ? 'center' : 'flex-start',
        paddingLeft: leading ? 0 : 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-h3)',
        fontWeight: 600,
        color: 'var(--text)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        maxWidth: '100%'
      }
    }, title), subtitle && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-caption)',
        color: 'var(--text-muted)'
      }
    }, subtitle)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 2
      }
    }, actions));
  }

  // ---- SegmentedTabs ----
  function SegmentedTabs({
    tabs = [],
    value,
    onChange,
    variant = 'segmented',
    style = {}
  }) {
    if (variant === 'underline') {
      return /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 4,
          borderBottom: '1px solid var(--border)',
          ...style
        }
      }, tabs.map(t => {
        const a = t.key === value;
        return /*#__PURE__*/React.createElement("button", {
          key: t.key,
          type: "button",
          onClick: () => onChange(t.key),
          style: {
            border: 'none',
            background: 'transparent',
            cursor: 'pointer',
            padding: '12px 14px',
            position: 'relative',
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-body)',
            fontWeight: a ? 600 : 500,
            color: a ? 'var(--text)' : 'var(--text-muted)',
            transition: 'color var(--dur-base) var(--ease-standard)'
          }
        }, t.label, /*#__PURE__*/React.createElement("span", {
          style: {
            position: 'absolute',
            left: 10,
            right: 10,
            bottom: -1,
            height: 2,
            borderRadius: 2,
            background: a ? 'var(--accent)' : 'transparent',
            transition: 'background var(--dur-base) var(--ease-standard)'
          }
        }));
      }));
    }
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 3,
        padding: 3,
        background: 'var(--surface-3)',
        borderRadius: 'var(--r-sm)',
        border: '1px solid var(--border)',
        ...style
      }
    }, tabs.map(t => {
      const a = t.key === value;
      return /*#__PURE__*/React.createElement("button", {
        key: t.key,
        type: "button",
        onClick: () => onChange(t.key),
        style: {
          flex: 1,
          border: 'none',
          cursor: 'pointer',
          padding: '8px 12px',
          borderRadius: 'calc(var(--r-sm) - 2px)',
          background: a ? 'var(--surface)' : 'transparent',
          boxShadow: a ? 'var(--shadow-sm)' : 'none',
          color: a ? 'var(--text)' : 'var(--text-muted)',
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body-sm)',
          fontWeight: a ? 600 : 500,
          transition: 'all var(--dur-base) var(--ease-standard)',
          WebkitTapHighlightColor: 'transparent'
        }
      }, t.label);
    }));
  }

  // ---- ListItem ----
  function ListItem({
    leading,
    title,
    subtitle,
    trailing,
    onClick,
    selected,
    divider,
    style = {}
  }) {
    const tap = !!onClick;
    const press = e => {
      if (tap) e.currentTarget.style.background = 'var(--surface-3)';
    };
    const rel = e => {
      if (tap) e.currentTarget.style.background = selected ? 'var(--accent-subtle)' : 'transparent';
    };
    return /*#__PURE__*/React.createElement("div", {
      onClick: onClick,
      onPointerDown: press,
      onPointerUp: rel,
      onPointerLeave: rel,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        minHeight: 'var(--tap-comfort)',
        padding: '10px 4px',
        background: selected ? 'var(--accent-subtle)' : 'transparent',
        cursor: tap ? 'pointer' : 'default',
        borderBottom: divider ? '1px solid var(--border)' : 'none',
        transition: 'background var(--dur-fast) var(--ease-standard)',
        WebkitTapHighlightColor: 'transparent',
        ...style
      }
    }, leading && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        flexShrink: 0
      }
    }, leading), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body)',
        fontWeight: 500,
        color: 'var(--text)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, title), subtitle && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body-sm)',
        color: 'var(--text-muted)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, subtitle)), trailing && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        flexShrink: 0,
        color: 'var(--text-muted)'
      }
    }, trailing));
  }

  // ---- BottomNav ----
  function BottomNav({
    items = [],
    value,
    onChange,
    style = {}
  }) {
    return /*#__PURE__*/React.createElement("nav", {
      style: {
        display: 'flex',
        alignItems: 'stretch',
        height: 'var(--tabbar-h)',
        background: 'var(--surface)',
        borderTop: '1px solid var(--border)',
        ...style
      }
    }, items.map(it => {
      const a = it.key === value;
      return /*#__PURE__*/React.createElement("button", {
        key: it.key,
        type: "button",
        onClick: () => onChange(it.key),
        style: {
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 4,
          border: 'none',
          background: 'transparent',
          cursor: 'pointer',
          padding: '6px 0',
          position: 'relative',
          color: a ? 'var(--accent)' : 'var(--text-muted)',
          transition: 'color var(--dur-base) var(--ease-standard)',
          WebkitTapHighlightColor: 'transparent'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'relative',
          display: 'inline-flex'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: it.icon,
        size: 22,
        stroke: a ? 2 : 1.7
      }), it.badge != null && /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          top: -4,
          right: -7,
          minWidth: 16,
          height: 16,
          padding: '0 4px',
          borderRadius: 'var(--r-pill)',
          background: 'var(--error)',
          color: '#fff',
          fontSize: 10,
          fontWeight: 700,
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '2px solid var(--surface)'
        }
      }, it.badge)), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-sans)',
          fontSize: 10,
          fontWeight: a ? 600 : 500,
          letterSpacing: '0.01em'
        }
      }, it.label));
    }));
  }

  // ---- FAB ----
  function FAB({
    icon = 'plus',
    onClick,
    label = 'Create',
    style = {}
  }) {
    const press = e => e.currentTarget.style.transform = 'scale(0.94)';
    const rel = e => e.currentTarget.style.transform = 'scale(1)';
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      "aria-label": label,
      onClick: onClick,
      onPointerDown: press,
      onPointerUp: rel,
      onPointerLeave: rel,
      style: {
        width: 56,
        height: 56,
        borderRadius: 'var(--r-pill)',
        border: 'none',
        background: 'var(--accent-fill)',
        color: 'var(--accent-fg)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: 'var(--shadow-accent)',
        cursor: 'pointer',
        transition: 'transform var(--dur-fast) var(--ease-standard)',
        WebkitTapHighlightColor: 'transparent',
        ...style
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 24,
      stroke: 2
    }));
  }

  // ---- Toast ----
  function Toast({
    title,
    message,
    tone = 'neutral',
    icon,
    action,
    onClose,
    style = {}
  }) {
    const tones = {
      neutral: 'var(--text-secondary)',
      accent: 'var(--accent)',
      success: 'var(--success)',
      warning: 'var(--warning)',
      error: 'var(--error)'
    };
    const c = tones[tone];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        gap: 12,
        padding: '14px 14px 14px 16px',
        background: 'var(--surface-2)',
        border: '1px solid var(--border)',
        borderLeft: `3px solid ${c}`,
        borderRadius: 'var(--r-md)',
        boxShadow: 'var(--shadow-lg)',
        ...style
      }
    }, icon && /*#__PURE__*/React.createElement("span", {
      style: {
        color: c,
        display: 'inline-flex',
        marginTop: 1
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 20
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body)',
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, title), message && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body-sm)',
        color: 'var(--text-secondary)',
        marginTop: 2
      }
    }, message)), action, onClose && /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onClose,
      "aria-label": "Dismiss",
      style: {
        border: 'none',
        background: 'transparent',
        color: 'var(--text-muted)',
        cursor: 'pointer',
        fontSize: 14
      }
    }, "\u2715"));
  }

  // ---- EmptyState ----
  function EmptyState({
    icon,
    title,
    description,
    action,
    style = {}
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        gap: 14,
        padding: '40px 24px',
        maxWidth: 360,
        margin: '0 auto',
        ...style
      }
    }, icon && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 64,
        height: 64,
        borderRadius: 'var(--r-lg)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--surface-3)',
        border: '1px solid var(--border)',
        color: 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 28
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-h3)',
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, title), description && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body)',
        color: 'var(--text-muted)',
        lineHeight: 'var(--lh-normal)'
      }
    }, description)), action && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4
      }
    }, action));
  }

  // ---- Skeleton ----
  function Skeleton({
    variant = 'line',
    width = '100%',
    height,
    radius,
    style = {}
  }) {
    const dims = {
      line: {
        width,
        height: height || 12,
        borderRadius: radius || 'var(--r-xs)'
      },
      block: {
        width,
        height: height || 80,
        borderRadius: radius || 'var(--r-md)'
      },
      circle: {
        width: width || 40,
        height: height || 40,
        borderRadius: '50%'
      }
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'linear-gradient(90deg, var(--surface-2) 25%, var(--surface-3) 37%, var(--surface-2) 63%)',
        backgroundSize: '400% 100%',
        animation: 'fshimmer 1.4s ease-in-out infinite',
        ...dims[variant],
        ...style
      }
    });
  }

  // ---- ProgressRing (small domain extra) ----
  function ProgressRing({
    value = 0,
    size = 40,
    stroke = 4,
    color = 'var(--accent)'
  }) {
    const r = (size - stroke) / 2,
      c = 2 * Math.PI * r,
      off = c * (1 - value / 100);
    return /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      style: {
        transform: 'rotate(-90deg)'
      }
    }, /*#__PURE__*/React.createElement("circle", {
      cx: size / 2,
      cy: size / 2,
      r: r,
      fill: "none",
      stroke: "var(--surface-3)",
      strokeWidth: stroke
    }), /*#__PURE__*/React.createElement("circle", {
      cx: size / 2,
      cy: size / 2,
      r: r,
      fill: "none",
      stroke: color,
      strokeWidth: stroke,
      strokeLinecap: "round",
      strokeDasharray: c,
      strokeDashoffset: off,
      style: {
        transition: 'stroke-dashoffset var(--dur-slow) var(--ease-standard)'
      }
    }));
  }
  Object.assign(window.ForgeUI, {
    AppBar,
    SegmentedTabs,
    ListItem,
    BottomNav,
    FAB,
    Toast,
    EmptyState,
    Skeleton,
    ProgressRing
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/forge-ui-nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/screen-auth.jsx
try { (() => {
/* Forge UI kit — Auth flow: Splash → Onboarding → Login. window.ForgeScreens.Auth */
(function () {
  const {
    Icon,
    Button,
    Input
  } = window.ForgeUI;
  const SLIDES = [{
    icon: 'layout-grid',
    color: 'var(--c-amber)',
    title: 'Your workspace, in your pocket',
    body: 'Every project, deploy and review — organized and vivid, wherever you are.'
  }, {
    icon: 'activity',
    color: 'var(--c-pink)',
    title: 'Know what needs you',
    body: 'A clear daily focus surfaces failing checks and pending reviews first.'
  }, {
    icon: 'sparkles',
    color: 'var(--c-violet)',
    title: 'Built for long sessions',
    body: 'A rich, colorful dark theme tuned to keep you energized, day or night.'
  }];
  function Logo({
    size = 44
  }) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        width: size,
        height: size,
        borderRadius: 'var(--r-md)',
        background: 'var(--grad-hero)',
        boxShadow: 'var(--shadow-accent)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "hexagon",
      size: size * 0.56,
      stroke: 2.4,
      color: "#fff"
    }));
  }
  function Auth({
    onAuthed
  }) {
    const [stage, setStage] = React.useState('splash'); // splash | onboard | login
    const [slide, setSlide] = React.useState(0);
    const [email, setEmail] = React.useState('lina@forge.dev');
    const [pw, setPw] = React.useState('••••••••');
    const [busy, setBusy] = React.useState(false);
    React.useEffect(() => {
      if (stage === 'splash') {
        const t = setTimeout(() => setStage('onboard'), 1400);
        return () => clearTimeout(t);
      }
    }, [stage]);
    if (stage === 'splash') {
      return /*#__PURE__*/React.createElement("div", {
        style: {
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 18,
          background: 'var(--bg)'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          animation: 'fpop var(--dur-slow) var(--ease-emphasized) both'
        }
      }, /*#__PURE__*/React.createElement(Logo, {
        size: 68
      })), /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: 'var(--font-sans)',
          fontSize: 26,
          fontWeight: 700,
          letterSpacing: '-0.01em',
          color: 'var(--text)'
        }
      }, "Forge"), /*#__PURE__*/React.createElement("style", null, '@keyframes fpop{from{transform:scale(.9)}to{transform:scale(1)}}'));
    }
    if (stage === 'onboard') {
      const s = SLIDES[slide];
      const last = slide === SLIDES.length - 1;
      return /*#__PURE__*/React.createElement("div", {
        style: {
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          padding: '24px var(--screen-pad) 28px'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          justifyContent: 'flex-end'
        }
      }, /*#__PURE__*/React.createElement("button", {
        type: "button",
        onClick: () => setStage('login'),
        style: {
          border: 'none',
          background: 'transparent',
          color: 'var(--text-muted)',
          fontFamily: 'var(--font-sans)',
          fontSize: 14,
          cursor: 'pointer',
          padding: 8
        }
      }, "Skip")), /*#__PURE__*/React.createElement("div", {
        key: slide,
        style: {
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          gap: 22,
          animation: 'fslide var(--dur-base) var(--ease-standard) both'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 96,
          height: 96,
          borderRadius: 'var(--r-xl)',
          background: s.color,
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#1A1207',
          boxShadow: `0 12px 32px ${s.color}`
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: s.icon,
        size: 42,
        stroke: 2
      })), /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: 'var(--font-sans)',
          fontSize: 24,
          fontWeight: 700,
          letterSpacing: '-0.01em',
          color: 'var(--text)',
          maxWidth: 300,
          lineHeight: 1.25
        }
      }, s.title), /*#__PURE__*/React.createElement("div", {
        style: {
          fontFamily: 'var(--font-sans)',
          fontSize: 15.5,
          color: 'var(--text-secondary)',
          maxWidth: 300,
          lineHeight: 1.55
        }
      }, s.body)), /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          justifyContent: 'center',
          gap: 7,
          marginBottom: 22
        }
      }, SLIDES.map((_, i) => /*#__PURE__*/React.createElement("span", {
        key: i,
        style: {
          width: i === slide ? 22 : 7,
          height: 7,
          borderRadius: 'var(--r-pill)',
          background: i === slide ? 'var(--accent)' : 'var(--border-strong)',
          transition: 'all var(--dur-base) var(--ease-standard)'
        }
      }))), /*#__PURE__*/React.createElement(Button, {
        fullWidth: true,
        onClick: () => last ? setStage('login') : setSlide(slide + 1),
        trailingIcon: /*#__PURE__*/React.createElement(Icon, {
          name: "arrow-right",
          size: 18
        })
      }, last ? 'Get started' : 'Next'), /*#__PURE__*/React.createElement("style", null, '@keyframes fslide{from{transform:translateY(10px)}to{transform:translateY(0)}}'));
    }

    // login
    const submit = () => {
      setBusy(true);
      setTimeout(() => onAuthed(), 900);
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        padding: '28px var(--screen-pad)',
        overflowY: 'auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 18,
        marginBottom: 28
      }
    }, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 26,
        fontWeight: 700,
        letterSpacing: '-0.01em',
        color: 'var(--text)',
        marginTop: 18
      }
    }, "Welcome back"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        color: 'var(--text-muted)',
        marginTop: 4
      }
    }, "Sign in to your Northwind workspace.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Work email",
      value: email,
      onChange: e => setEmail(e.target.value),
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "mail",
        size: 18
      })
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Password",
      type: "password",
      value: pw,
      onChange: e => setPw(e.target.value),
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "lock",
        size: 18
      }),
      trailingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "eye",
        size: 18,
        color: "var(--text-muted)"
      })
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'flex-end'
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      style: {
        border: 'none',
        background: 'transparent',
        color: 'var(--accent)',
        fontFamily: 'var(--font-sans)',
        fontSize: 13.5,
        fontWeight: 500,
        cursor: 'pointer'
      }
    }, "Forgot password?")), /*#__PURE__*/React.createElement(Button, {
      fullWidth: true,
      loading: busy,
      onClick: submit
    }, "Sign in"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        margin: '6px 0'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, "or"), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border)'
      }
    })), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      fullWidth: true,
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "github",
        size: 18
      }),
      onClick: submit
    }, "Continue with GitHub")), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 'auto',
        paddingTop: 24,
        textAlign: 'center',
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        color: 'var(--text-muted)'
      }
    }, "New here? ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--accent)',
        fontWeight: 500
      }
    }, "Create an account")));
  }
  window.ForgeScreens = window.ForgeScreens || {};
  window.ForgeScreens.Auth = Auth;
  window.ForgeScreens.Logo = Logo;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/screen-auth.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/screen-details.jsx
try { (() => {
/* Forge UI kit — Project details. window.ForgeScreens.Details */
(function () {
  const {
    Icon,
    Card,
    Badge,
    Avatar,
    Button,
    IconButton,
    AppBar,
    SegmentedTabs,
    ProgressRing
  } = window.ForgeUI;
  const D = window.ForgeData;
  function MetaTile({
    icon,
    label,
    value,
    tone
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        background: 'var(--surface-2)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--r-md)',
        padding: '12px 14px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        color: 'var(--text-muted)',
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: icon,
      size: 15
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 12
      }
    }, label)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 18,
        fontWeight: 700,
        color: tone || 'var(--text)'
      }
    }, value));
  }
  function Details({
    project,
    onBack
  }) {
    const p = project || D.projects[0];
    const [tab, setTab] = React.useState('overview');
    const commits = [{
      h: 'a1f9c2',
      m: 'Add idempotency keys to charge endpoint',
      who: 'Omar R',
      when: '6m'
    }, {
      h: '7d34be',
      m: 'Bump payout retry budget to 5',
      who: 'Lina K',
      when: '2h'
    }, {
      h: 'c0e811',
      m: 'Fix webhook signature verification',
      who: 'Sara M',
      when: '5h'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: p.name,
      subtitle: p.lang,
      leading: /*#__PURE__*/React.createElement(IconButton, {
        label: "Back",
        onClick: onBack
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "arrow-left",
        size: 22
      })),
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
        label: "Star"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "star",
        size: 20
      })), /*#__PURE__*/React.createElement(IconButton, {
        label: "More"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "ellipsis-vertical",
        size: 20
      }))),
      scrolled: true
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '16px var(--screen-pad) 40px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: D.statusTone[p.status],
      dot: true
    }, p.status), /*#__PURE__*/React.createElement(Badge, {
      tone: p.checks === 'failing' ? 'error' : 'success',
      variant: "subtle"
    }, p.checks, " checks"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, p.branch)), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        color: 'var(--text-secondary)',
        margin: '0 0 14px',
        lineHeight: 1.55
      }
    }, p.desc), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement(Button, {
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "rocket",
        size: 18
      }),
      style: {
        flex: 1
      }
    }, "Deploy"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "git-pull-request",
        size: 18
      }),
      style: {
        flex: 1
      }
    }, "Open PR")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 10,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(MetaTile, {
      icon: "star",
      label: "Stars",
      value: p.stars
    }), /*#__PURE__*/React.createElement(MetaTile, {
      icon: "git-commit-horizontal",
      label: "Build",
      value: p.progress + '%',
      tone: p.checks === 'failing' ? 'var(--error)' : 'var(--success)'
    }), /*#__PURE__*/React.createElement(MetaTile, {
      icon: "users",
      label: "Team",
      value: p.members.length
    })), /*#__PURE__*/React.createElement(SegmentedTabs, {
      value: tab,
      onChange: setTab,
      variant: "underline",
      style: {
        marginBottom: 8
      },
      tabs: [{
        key: 'overview',
        label: 'Overview'
      }, {
        key: 'commits',
        label: 'Commits'
      }, {
        key: 'team',
        label: 'Team'
      }]
    }), tab === 'overview' && /*#__PURE__*/React.createElement(Card, {
      padding: "16px",
      style: {
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(ProgressRing, {
      value: p.progress,
      size: 56,
      stroke: 5,
      color: p.checks === 'failing' ? 'var(--warning)' : 'var(--accent)'
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, "Release readiness"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, p.progress, "% \xB7 ", p.checks === 'failing' ? '2 blocking checks' : 'all checks green')))), tab === 'commits' && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, commits.map(c => /*#__PURE__*/React.createElement("div", {
      key: c.h,
      style: {
        display: 'flex',
        gap: 12,
        padding: '12px 0',
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "git-commit-horizontal",
      size: 18,
      color: "var(--text-muted)",
      style: {
        marginTop: 2
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        color: 'var(--text)'
      }
    }, c.m), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11.5,
        color: 'var(--text-muted)',
        marginTop: 3
      }
    }, c.h, " \xB7 ", c.who, " \xB7 ", c.when, " ago"))))), tab === 'team' && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, p.members.map(m => /*#__PURE__*/React.createElement("div", {
      key: m,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '11px 0',
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: m,
      status: m === 'Lina K' ? 'online' : 'offline'
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 14.5,
        fontWeight: 500,
        color: 'var(--text)'
      }
    }, m), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 12.5,
        color: 'var(--text-muted)'
      }
    }, m === 'Lina K' ? 'Maintainer' : 'Contributor')), /*#__PURE__*/React.createElement(Icon, {
      name: "message-square",
      size: 18,
      color: "var(--text-muted)"
    }))))));
  }
  window.ForgeScreens = window.ForgeScreens || {};
  window.ForgeScreens.Details = Details;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/screen-details.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/screen-home.jsx
try { (() => {
/* Forge UI kit — Home (dashboard). window.ForgeScreens.Home */
(function () {
  const {
    Icon,
    Card,
    Badge,
    Chip,
    Avatar,
    IconButton,
    AppBar,
    ProgressRing
  } = window.ForgeUI;
  const D = window.ForgeData;
  function HeroStat({
    value,
    label
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 24,
        fontWeight: 700,
        letterSpacing: '-0.01em',
        color: '#fff'
      }
    }, value), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 11.5,
        color: 'rgba(255,255,255,0.78)'
      }
    }, label));
  }
  function ProjectRow({
    p,
    onOpen
  }) {
    return /*#__PURE__*/React.createElement(Card, {
      interactive: true,
      onClick: () => onOpen(p),
      padding: "14px",
      style: {
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 40,
        borderRadius: 'var(--r-sm)',
        background: D.langColors[p.lang],
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        boxShadow: `0 4px 12px ${D.langColors[p.lang]}55`
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 15,
        fontWeight: 700,
        color: 'rgba(15,12,8,0.82)'
      }
    }, p.lang[0])), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: 600,
        color: 'var(--text)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, p.name), /*#__PURE__*/React.createElement(Badge, {
      tone: D.statusTone[p.status],
      dot: true
    }, p.status)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginTop: 3,
        fontFamily: 'var(--font-mono)',
        fontSize: 11.5,
        color: 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "git-branch",
      size: 13
    }), /*#__PURE__*/React.createElement("span", null, p.branch), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, p.updated, " ago"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 4,
        flexShrink: 0,
        color: p.checks === 'failing' ? 'var(--error)' : 'var(--success)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: p.checks === 'failing' ? 'x-circle' : 'check-circle-2',
      size: 18
    }))));
  }
  function ActivityRow({
    a
  }) {
    const tones = {
      accent: 'var(--accent)',
      error: 'var(--error)',
      success: 'var(--success)',
      neutral: 'var(--text-secondary)'
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        padding: '11px 0',
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 'var(--r-sm)',
        flexShrink: 0,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--surface-3)',
        color: tones[a.tone]
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: a.icon,
      size: 16
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13.5,
        color: 'var(--text-secondary)',
        lineHeight: 1.45
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        color: 'var(--text)',
        fontWeight: 600
      }
    }, a.who), " ", a.action, " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text)'
      }
    }, a.target)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, a.repo, " \xB7 ", a.when, " ago")));
  }
  function Home({
    onOpenProject,
    onScroll,
    onSearch,
    onBell,
    unread
  }) {
    const [filter, setFilter] = React.useState('active');
    const filters = [{
      key: 'active',
      label: 'Active'
    }, {
      key: 'mine',
      label: 'Mine'
    }, {
      key: 'all',
      label: 'All'
    }];
    const list = filter === 'all' ? D.projects : filter === 'mine' ? D.projects.filter(p => p.members.includes('Lina K')) : D.projects.filter(p => p.status !== 'live').concat(D.projects.filter(p => p.status === 'live'));
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: "Forge",
      subtitle: D.user.workspace + ' workspace',
      leading: /*#__PURE__*/React.createElement("div", {
        style: {
          padding: '0 4px'
        }
      }, /*#__PURE__*/React.createElement(Avatar, {
        name: D.user.name,
        size: "md",
        status: "online"
      })),
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
        label: "Search",
        onClick: onSearch
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "search",
        size: 21
      })), /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'relative',
          display: 'inline-flex'
        }
      }, /*#__PURE__*/React.createElement(IconButton, {
        label: "Notifications",
        onClick: onBell
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "bell",
        size: 21
      })), unread > 0 && /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          top: 7,
          right: 7,
          width: 8,
          height: 8,
          borderRadius: '50%',
          background: 'var(--error)',
          border: '2px solid var(--surface)'
        }
      })))
    }), /*#__PURE__*/React.createElement("div", {
      onScroll: onScroll,
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '8px var(--screen-pad) 96px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--grad-hero)',
        borderRadius: 'var(--r-lg)',
        padding: '18px 18px 16px',
        margin: '8px 0 24px',
        boxShadow: '0 14px 36px rgba(255,138,34,0.28)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 24,
        fontWeight: 700,
        letterSpacing: '-0.01em',
        color: '#1A1207'
      }
    }, "Good evening, Lina"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13.5,
        fontWeight: 500,
        color: 'rgba(26,18,7,0.72)',
        marginTop: 2
      }
    }, "Tuesday, June 10 \xB7 4 things need you")), /*#__PURE__*/React.createElement("span", {
      style: {
        background: 'rgba(15,10,4,0.26)',
        color: '#fff',
        fontFamily: 'var(--font-sans)',
        fontSize: 11,
        fontWeight: 700,
        padding: '5px 9px',
        borderRadius: 'var(--r-pill)',
        whiteSpace: 'nowrap'
      }
    }, D.summary.uptime, "% up")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginTop: 16,
        background: 'rgba(12,9,16,0.30)',
        borderRadius: 'var(--r-md)',
        padding: '12px 14px',
        backdropFilter: 'blur(2px)'
      }
    }, /*#__PURE__*/React.createElement(HeroStat, {
      value: D.summary.deploys,
      label: "Deploys"
    }), /*#__PURE__*/React.createElement(HeroStat, {
      value: D.summary.prs,
      label: "Open PRs"
    }), /*#__PURE__*/React.createElement(HeroStat, {
      value: D.summary.failing,
      label: "Failing"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(ProgressRing, {
      value: D.summary.coverage,
      size: 42,
      color: "#fff"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 11,
        color: 'rgba(255,255,255,0.85)'
      }
    }, "Coverage")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 18,
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, "Projects"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, filters.map(f => /*#__PURE__*/React.createElement(Chip, {
      key: f.key,
      selected: filter === f.key,
      onClick: () => setFilter(f.key)
    }, f.label)))), list.map(p => /*#__PURE__*/React.createElement(ProjectRow, {
      key: p.id,
      p: p,
      onOpen: onOpenProject
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 24
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 18,
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, "Recent activity"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6
      }
    }, D.activity.map(a => /*#__PURE__*/React.createElement(ActivityRow, {
      key: a.id,
      a: a
    }))))));
  }
  window.ForgeScreens = window.ForgeScreens || {};
  window.ForgeScreens.Home = Home;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/screen-home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/screen-profile.jsx
try { (() => {
/* Forge UI kit — Profile + Settings. window.ForgeScreens.Profile */
(function () {
  const {
    Icon,
    Card,
    Badge,
    Avatar,
    Switch,
    AppBar,
    ListItem,
    IconButton
  } = window.ForgeUI;
  const D = window.ForgeData;
  function Group({
    title,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 12,
        fontWeight: 600,
        color: 'var(--text-muted)',
        textTransform: 'uppercase',
        letterSpacing: '0.06em',
        margin: '0 4px 8px'
      }
    }, title), /*#__PURE__*/React.createElement(Card, {
      padding: "2px 14px"
    }, children));
  }
  function Row({
    icon,
    color,
    title,
    subtitle,
    trailing,
    onClick,
    last
  }) {
    return /*#__PURE__*/React.createElement(ListItem, {
      onClick: onClick,
      divider: !last,
      leading: /*#__PURE__*/React.createElement("span", {
        style: {
          width: 32,
          height: 32,
          borderRadius: 'var(--r-sm)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'var(--surface-3)',
          color: color || 'var(--text-secondary)'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: icon,
        size: 17
      })),
      title: title,
      subtitle: subtitle,
      trailing: trailing
    });
  }
  function Profile() {
    const [push, setPush] = React.useState(true);
    const [digest, setDigest] = React.useState(false);
    const [scrolled, setScrolled] = React.useState(false);
    const [accent, setAccent] = React.useState('amber');
    const swatches = [{
      key: 'amber',
      c: 'var(--c-amber)'
    }, {
      key: 'coral',
      c: 'var(--c-coral)'
    }, {
      key: 'pink',
      c: 'var(--c-pink)'
    }, {
      key: 'violet',
      c: 'var(--c-violet)'
    }, {
      key: 'cyan',
      c: 'var(--c-cyan)'
    }, {
      key: 'green',
      c: 'var(--c-green)'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: "Profile",
      scrolled: scrolled,
      actions: /*#__PURE__*/React.createElement(IconButton, {
        label: "Edit"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "square-pen",
        size: 20
      }))
    }), /*#__PURE__*/React.createElement("div", {
      onScroll: e => setScrolled(e.target.scrollTop > 4),
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '8px var(--screen-pad) 96px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        padding: '14px 4px 22px'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: D.user.name,
      size: "lg",
      status: "online"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 20,
        fontWeight: 700,
        color: 'var(--text)'
      }
    }, D.user.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        color: 'var(--text-muted)'
      }
    }, D.user.role, " \xB7 @", D.user.handle), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "accent",
      variant: "subtle"
    }, D.user.workspace, " workspace")))), /*#__PURE__*/React.createElement(Group, {
      title: "Account"
    }, /*#__PURE__*/React.createElement(Row, {
      icon: "user-round",
      title: "Personal info",
      subtitle: "Name, email, handle",
      trailing: /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 18
      }),
      onClick: () => {}
    }), /*#__PURE__*/React.createElement(Row, {
      icon: "shield-check",
      color: "var(--success)",
      title: "Security",
      subtitle: "Password, 2FA, sessions",
      trailing: /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 18
      }),
      onClick: () => {}
    }), /*#__PURE__*/React.createElement(Row, {
      icon: "key-round",
      title: "API tokens",
      subtitle: "3 active",
      trailing: /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 18
      }),
      onClick: () => {},
      last: true
    })), /*#__PURE__*/React.createElement(Group, {
      title: "Preferences"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        minHeight: 'var(--tap-comfort)',
        padding: '10px 0',
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 'var(--r-sm)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--surface-3)',
        color: 'var(--accent)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "palette",
      size: 17
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body)',
        fontWeight: 500,
        color: 'var(--text)'
      }
    }, "Accent color"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 9,
        marginTop: 8
      }
    }, swatches.map(s => /*#__PURE__*/React.createElement("button", {
      key: s.key,
      type: "button",
      onClick: () => setAccent(s.key),
      "aria-label": s.key,
      style: {
        width: 24,
        height: 24,
        borderRadius: '50%',
        background: s.c,
        cursor: 'pointer',
        padding: 0,
        border: accent === s.key ? '2px solid var(--text)' : '2px solid transparent',
        outline: accent === s.key ? '2px solid ' + s.c : 'none',
        outlineOffset: 1,
        transition: 'transform var(--dur-fast) var(--ease-standard)'
      }
    }))))), /*#__PURE__*/React.createElement(Row, {
      icon: "bell",
      title: "Push notifications",
      trailing: /*#__PURE__*/React.createElement(Switch, {
        checked: push,
        onChange: setPush
      })
    }), /*#__PURE__*/React.createElement(Row, {
      icon: "mail",
      title: "Email digests",
      subtitle: "Weekly summary",
      trailing: /*#__PURE__*/React.createElement(Switch, {
        checked: digest,
        onChange: setDigest
      }),
      last: true
    })), /*#__PURE__*/React.createElement(Group, {
      title: "Support"
    }, /*#__PURE__*/React.createElement(Row, {
      icon: "life-buoy",
      title: "Help center",
      trailing: /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 18
      }),
      onClick: () => {}
    }), /*#__PURE__*/React.createElement(Row, {
      icon: "message-circle",
      title: "Send feedback",
      trailing: /*#__PURE__*/React.createElement(Icon, {
        name: "chevron-right",
        size: 18
      }),
      onClick: () => {}
    }), /*#__PURE__*/React.createElement(Row, {
      icon: "log-out",
      color: "var(--error)",
      title: "Sign out",
      onClick: () => {},
      last: true
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--text-muted)',
        paddingTop: 4
      }
    }, "Forge \xB7 v2.4.1")));
  }
  window.ForgeScreens = window.ForgeScreens || {};
  window.ForgeScreens.Profile = Profile;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/screen-profile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/forge-app/screen-search.jsx
try { (() => {
/* Forge UI kit — Search. window.ForgeScreens.Search */
(function () {
  const {
    Icon,
    SearchBar,
    Chip,
    Badge,
    EmptyState,
    Avatar
  } = window.ForgeUI;
  const D = window.ForgeData;
  const RECENT = ['payments idempotency', 'rotate signing keys', 'rate limiting', 'embed eval'];
  const SCOPES = [{
    key: 'all',
    label: 'All'
  }, {
    key: 'projects',
    label: 'Projects'
  }, {
    key: 'prs',
    label: 'PRs'
  }, {
    key: 'people',
    label: 'People'
  }];
  function Search({
    onOpenProject
  }) {
    const [q, setQ] = React.useState('');
    const [scope, setScope] = React.useState('all');
    const results = q ? D.projects.filter(p => (p.name + p.lang + p.desc).toLowerCase().includes(q.toLowerCase())) : [];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '12px var(--screen-pad) 10px',
        background: 'var(--surface)',
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement(SearchBar, {
      value: q,
      onChange: e => setQ(e.target.value),
      onClear: () => setQ(''),
      placeholder: "Search Northwind",
      leadingIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "search",
        size: 20
      })
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginTop: 12,
        overflowX: 'auto'
      }
    }, SCOPES.map(s => /*#__PURE__*/React.createElement(Chip, {
      key: s.key,
      selected: scope === s.key,
      onClick: () => setScope(s.key)
    }, s.label)))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '16px var(--screen-pad) 96px'
      }
    }, !q && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        fontWeight: 600,
        color: 'var(--text-muted)',
        textTransform: 'uppercase',
        letterSpacing: '0.06em',
        marginBottom: 10
      }
    }, "Recent"), RECENT.map(r => /*#__PURE__*/React.createElement("button", {
      key: r,
      type: "button",
      onClick: () => setQ(r),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        width: '100%',
        padding: '11px 4px',
        border: 'none',
        borderBottom: '1px solid var(--border)',
        background: 'transparent',
        cursor: 'pointer',
        color: 'var(--text-secondary)',
        fontFamily: 'var(--font-sans)',
        fontSize: 14.5,
        textAlign: 'left'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "clock",
      size: 17,
      color: "var(--text-muted)"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, r), /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-left",
      size: 16,
      color: "var(--text-muted)"
    })))), q && results.length === 0 && /*#__PURE__*/React.createElement(EmptyState, {
      icon: "search-x",
      title: "No matches",
      description: `Nothing in Northwind matches “${q}”. Try a different term or scope.`
    }), q && results.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        color: 'var(--text-muted)',
        marginBottom: 10
      }
    }, results.length, " project", results.length > 1 ? 's' : ''), results.map(p => /*#__PURE__*/React.createElement("div", {
      key: p.id,
      onClick: () => onOpenProject(p),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '12px 4px',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 36,
        height: 36,
        borderRadius: 'var(--r-sm)',
        background: 'var(--surface-3)',
        border: '1px solid var(--border)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: D.langColors[p.lang]
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: 600,
        color: 'var(--text)'
      }
    }, p.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 13,
        color: 'var(--text-muted)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, p.desc)), /*#__PURE__*/React.createElement(Badge, {
      tone: D.statusTone[p.status],
      dot: true
    }, p.status))))));
  }
  window.ForgeScreens = window.ForgeScreens || {};
  window.ForgeScreens.Search = Search;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/forge-app/screen-search.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchBar = __ds_scope.SearchBar;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.AppBar = __ds_scope.AppBar;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.ListItem = __ds_scope.ListItem;

__ds_ns.SegmentedTabs = __ds_scope.SegmentedTabs;

})();
